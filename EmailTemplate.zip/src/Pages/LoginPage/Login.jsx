

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Form, Button, Container, Row, Col, Alert, Image } from "react-bootstrap";
import "./Login.css";
// import LOGINLOGO from "./loginpageimage.png";
// import LOGINLOGO from "./login-images.jpg";
import LOGINLOGO from "./purplelogin.png";
import LOGO from "./htc-logo.png";

const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState(""); 
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch("http://localhost:8080/users");
            if (response.ok) {
                const users = await response.json();
                const user = users.find(
                    (u) => u.email === email && u.password === password
                );
                if (user) {
                    localStorage.setItem("authToken", user.token);
                    localStorage.setItem("username", user.name);
                    navigate("/dashboard");
                } else {
                    setError("Invalid credentials. Please try again.");
                }
            } else {
                setError("Unable to fetch users. Please try again later.");
            }
        } catch (error) {
            setError("An error occurred. Please try again.");
        }
    };

    return (
        <Container fluid className="login-container">
            <Row className="login-row">
                {/* Left Side - Image */}
                <Col   md={8} lg={8} className="leftside-image">
                    <Image src={LOGINLOGO} className="img-fluid" alt="Login Logo" />
                </Col>

                {/* Right Side - Login Form */}
                <Col xs={12} sm={12} md={4} lg={4} className="rightside-form">
                    {/* Fixed Logo in Top Left */}
                    <div className="Rightside-container">
                    <div className="logo-container">
                        <Image src={LOGO} alt="HTC Logo" className="company-logo" />
                    </div>

                    <div className="form-content">
                        <h5>Sign in With HTC INC AD Credential</h5>
                        <Form onSubmit={handleLogin}>
                            
                            <Form.Group controlId="formEmail" className="mb-3">
                                <Form.Control
                                    type="email"
                                    placeholder="Enter email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                    className="input-box"
                                />
                            </Form.Group>

                            <Form.Group controlId="formPassword" className="mb-3">
                                <Form.Control
                                    type="password"
                                    placeholder="Password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                    className="input-box"
                                />
                            </Form.Group>

                            <Button  type="submit" className="w-100 login-btn">
                                Login
                            </Button>
                        </Form>

                        {error && <Alert variant="danger" className="mt-3">{error}</Alert>}
                    </div>
                    </div></Col>
            </Row>
        </Container>
    );
};

export default Login;





