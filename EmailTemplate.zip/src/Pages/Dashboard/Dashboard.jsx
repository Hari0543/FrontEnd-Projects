// import React, { useState, useEffect } from 'react';
// import axios from "axios";
// import Header from "../../components/Header/Header";
// import LeftMenu from "../../components/LeftMenu/LeftMenu";
// import MainContent from "../../components/MainContent";
// import TemplateEditor from "../../components/TemplateEditor/TemplateEditor";
// import TemplateEdit from "../../components/TemplateEdit/TemplateEdit";
// import "./Dashboard.css";

// const Dashboard = () => {
//   const [templates, setTemplates] = useState([]);
//   const [isEditorOpen, setIsEditorOpen] = useState(false);
//   const [isTemplatesOpen, setIsTemplatesOpen] = useState(false);
//   const [selectedFile, setSelectedFile] = useState(null);
//   const [savedContent, setSavedContent] = useState("");
//   const [isSavedAreaVisible, setIsSavedAreaVisible] = useState(false);

//   useEffect(() => {
//     fetchTemplates();
//   }, []);

//   const fetchTemplates = async () => {
//     try {
//       const response = await axios.get("http://localhost:8080/templates");
//       setTemplates(response.data || []);
//     } catch (error) {
//       console.error("Error fetching templates:", error);
//       alert("Failed to load templates.");
//     }
//   };

//   const handleTemplateEditorClick = () => {
//     setIsEditorOpen(true);
//     setIsTemplatesOpen(false);
//     setIsSavedAreaVisible(false);
//     setSelectedFile(null);
//   };

//   const handleTemplatesClick = () => {
//     setIsTemplatesOpen(true);
//     setIsEditorOpen(false);
//     setIsSavedAreaVisible(false);
//   };

//   const handleViewTemplate = async (fileName) => {
//     try {
//       const template = templates.find((file) => file.fileName === fileName);
//       if (template) {
//         setSavedContent(template.content);
//         setSelectedFile(template);
//         setIsTemplatesOpen(false);
//         setIsSavedAreaVisible(true);
//       }
//     } catch (error) {
//       console.error("Error loading template:", error);
//       alert("Failed to load template content.");
//     }
//   };
// const handleClearSavedArea = () => {
//     setSavedContent("");
//     setIsSavedAreaVisible(false);
//   };

//   const handleSave = async (fileName, content) => {
//     try {
//       const existingTemplate = templates.find((t) =>
//         (selectedFile?.id && t.id === selectedFile.id) || t.fileName === fileName
//       );
  
//       if (existingTemplate) {
//         // Update
//         await axios.put(`http://localhost:8080/templates/${existingTemplate.id}`, {
//           ...existingTemplate,
//           fileName,
//           content
//         });
//         alert("Template updated successfully!");
//       } else {
//         // Create
//         const response = await axios.post("http://localhost:8080/templates", {
//           fileName,
//           content
//         });
//         setTemplates((prev) => [...prev, response.data]);
//         alert("Template saved successfully!");
//       }
  
//       setSavedContent(content);
//       setSelectedFile({ fileName, content });
//       setIsEditorOpen(false);
//       setIsSavedAreaVisible(true);
//       fetchTemplates(); // refresh the template list
//     } catch (error) {
//       console.error("Error saving/updating template:", error);
//       alert("Failed to update template.");
//     }
//   };
  

//   return (
//     <div className="dashboard">
//       <Header />
//       <div className="dashboard-body">
//         <LeftMenu
//           onTemplateEditorClick={handleTemplateEditorClick}
//           onTemplatesClick={handleTemplatesClick}
//         />

//         {isEditorOpen && (
//           <TemplateEditor
//             onSave={handleSave}
//             selectedFile={selectedFile}
//           />
//         )}
//       {isTemplatesOpen && (
//   <MainContent
//     onViewTemplate={handleViewTemplate}
//     templates={templates}
//   />
// )}
//         {isSavedAreaVisible && (
//        <TemplateEdit
//        savedContent={savedContent}
//        handleClearSavedArea={handleClearSavedArea}
  
//        selectedFile={selectedFile}
//        onTemplateDeleted={fetchTemplates}
//      />
//         )}
//       </div>
//     </div>
//   );
// };

// export default Dashboard;

// import React, { useState, useEffect } from 'react';
// import axios from "axios";
// import Header from "../../components/Header/Header";
// import LeftMenu from "../../components/LeftMenu/LeftMenu";
// import MainContent from "../../components/MainContent";
// import TemplateEdit from "../../components/TemplateEdit/TemplateEdit";
// import "./Dashboard.css";

// const Dashboard = () => {
//   const [templates, setTemplates] = useState([]);
//   const [selectedFile, setSelectedFile] = useState(null);
//   const [savedContent, setSavedContent] = useState("");

//   useEffect(() => {
//     fetchTemplates();
//   }, []);

//   const fetchTemplates = async () => {
//     try {
//       const response = await axios.get("http://localhost:8080/templates");
//       setTemplates(response.data || []);
//     } catch (error) {
//       console.error("Error fetching templates:", error);
//       alert("Failed to load templates.");
//     }
//   };

//   const handleViewTemplate = async (fileName) => {
//     try {
//       const template = templates.find((file) => file.fileName === fileName);
//       if (template) {
//         setSavedContent(template.content);
//         setSelectedFile(template);
//       }
//     } catch (error) {
//       console.error("Error loading template:", error);
//       alert("Failed to load template content.");
//     }
//   };

//   const handleClearSavedArea = () => {
//     setSavedContent("");
//     setSelectedFile(null);
//   };

//   const handleTemplateDeleted = () => {
//     fetchTemplates();
//   };

//   return (
//     <div className="dashboard">
//       <Header />
//       <div className="dashboard-body">
//         <LeftMenu />
//         <div className="content-area">
//           <MainContent
//             onViewTemplate={handleViewTemplate}
//             templates={templates}
//           />
//           {selectedFile && (
//             <TemplateEdit
//               savedContent={savedContent}
//               handleClearSavedArea={handleClearSavedArea}
//               selectedFile={selectedFile}
//               onTemplateDeleted={handleTemplateDeleted}
//             />
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dashboard;

import React, { useState, useEffect } from 'react';
import axios from "axios";
import Header from "../../components/Header/Header";
import LeftMenu from "../../components/LeftMenu/LeftMenu";
import MainContent from "../../components/MainContent";
import TemplateEditor from "../../components/TemplateEditor/TemplateEditor";
import TemplateEdit from "../../components/TemplateEdit/TemplateEdit";
import "./Dashboard.css";

const Dashboard = () => {
  const [templates, setTemplates] = useState([]);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [isTemplatesOpen, setIsTemplatesOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [savedContent, setSavedContent] = useState("");
  const [isSavedAreaVisible, setIsSavedAreaVisible] = useState(false);

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    try {
      const response = await axios.get("http://localhost:8080/templates");
      setTemplates(response.data || []);
    } catch (error) {
      console.error("Error fetching templates:", error);
      alert("Failed to load templates.");
    }
  };

  const handleTemplateEditorClick = () => {
    setIsEditorOpen(true);
    setIsTemplatesOpen(false);
    setIsSavedAreaVisible(false);
    setSelectedFile(null);
  };

  const handleTemplatesClick = () => {
    setIsTemplatesOpen(true);
    setIsEditorOpen(false);
    setIsSavedAreaVisible(false);
  };

  const handleViewTemplate = (fileName) => {
    const template = templates.find((file) => file.fileName === fileName);
    if (template) {
      setSavedContent(template.content);
      setSelectedFile(template);
      setIsSavedAreaVisible(true);
    }
  };

  const handleClearSavedArea = () => {
    setSavedContent("");
    setIsSavedAreaVisible(false);
    setSelectedFile(null);
  };

  const handleTemplateDeleted = () => {
    fetchTemplates();
    handleClearSavedArea();
  };

  const handleSave = async (fileName, content) => {
    try {
      const existingTemplate = templates.find(
        (t) => (selectedFile?.id && t.id === selectedFile.id) || t.fileName === fileName
      );

      if (existingTemplate) {
        await axios.put(`http://localhost:8080/templates/${existingTemplate.id}`, {
          ...existingTemplate,
          fileName,
          content,
        });
        alert("Template updated successfully!");
      } else {
        const response = await axios.post("http://localhost:8080/templates", {
          fileName,
          content,
        });
        setTemplates((prev) => [...prev, response.data]);
        alert("Template saved successfully!");
      }

      setSavedContent(content);
      setSelectedFile({ fileName, content });
      setIsEditorOpen(false);
      setIsSavedAreaVisible(true);
      fetchTemplates();
    } catch (error) {
      console.error("Error saving/updating template:", error);
      alert("Failed to update template.");
    }
  };

  return (
    <div className="dashboard">
      <Header />
      <div className="dashboard-body">
        <LeftMenu
          onTemplateEditorClick={handleTemplateEditorClick}
          onTemplatesClick={handleTemplatesClick}
        />

        <div className="content-area" style={{width:"100%"}}>
          {isEditorOpen && (
            <TemplateEditor
              onSave={handleSave}
              selectedFile={selectedFile}
            />
          )}

          {isTemplatesOpen && (
            <>
              <MainContent
                onViewTemplate={handleViewTemplate}
                templates={templates}
              />
              {isSavedAreaVisible && (
                <TemplateEdit
                  savedContent={savedContent}
                  handleClearSavedArea={handleClearSavedArea}
                  selectedFile={selectedFile}
                  onTemplateDeleted={handleTemplateDeleted}
                />
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
