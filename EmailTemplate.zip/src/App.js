
import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Login from "./Pages/LoginPage/Login";
import Dashboard from "./Pages/Dashboard/Dashboard";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-quill/dist/quill.snow.css';
const App = () => {
    const isAuthenticated = localStorage.getItem("authToken"); // Check for token

    return (
        <Router>
            <Routes>
                <Route 
                    path="/" 
                    element={<Login />} 
                />
                
                <Route 
                    path="/dashboard" 
                    element={
                        isAuthenticated ? <Dashboard /> : <Navigate to="/login" />
                    } 
                />
                {/* Redirect the root path to login
                <Route 
                    path="*" 
                    element={<Navigate to="/login" />} 
                /> */}
            </Routes>
        </Router>
    );
};

export default App;
// import React from "react";
// import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
// import Login from "./Pages/LoginPage/Login";
// import Dashboard from "./Pages/Dashboard/Dashboard";
// import 'bootstrap/dist/css/bootstrap.min.css';
// const App = () => {
//     const isAuthenticated = localStorage.getItem("authToken"); // Check for token

//     return (
//         <Router>
//             <Routes>
//                 <Route 
//                     path="/login" 
//                     element={<Login />} 
//                 />
//                     <Route 
//                     path="/dashboard" 
//                     element={
//                         <Dashboard />
//                     } 
//                 />
//                 {/* <Route 
//                     path="/dashboard" 
//                     element={
//                         isAuthenticated ? <Dashboard /> : <Navigate to="/login" />
//                     } 
//                 /> */}
//                 {/* Redirect the root path to login
//                 <Route 
//                     path="*" 
//                     element={<Navigate to="/login" />} 
//                 /> */}
//             </Routes>
//         </Router>
//     );
// };

// export default App;
