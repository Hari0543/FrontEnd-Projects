import React from 'react';
import "./TemplateEdit.css";
import axios from 'axios';
import { FaTrash } from "react-icons/fa";
import { Document, Packer, Paragraph, TextRun } from "docx";
import { saveAs } from "file-saver";

const TemplateEdit = ({ savedContent, handleClearSavedArea, selectedFile, onTemplateDeleted }) => {
    const saveDocxToJsonServer = async () => {
        const doc = new Document({
            sections: [
                {
                    properties: {},
                    children: [
                        new Paragraph({
                            children: [
                                new TextRun({
                                    text: savedContent.replace(/<[^>]+>/g, ''),
                                    font: "Arial",
                                    size: 24,
                                }),
                            ],
                        }),
                    ],
                },
            ],
        });
    
        try {
            const blob = await Packer.toBlob(doc);
            const reader = new FileReader();
    
            reader.onloadend = async () => {
                const base64String = reader.result;
    
                const payload = {
                    fileName: selectedFile?.fileName || "template",
                    fileData: base64String // base64-encoded .docx file
                };
    
                const res = await axios.post("http://localhost:8080/templates", payload);
                alert("Template saved to json-server!");
                console.log("Saved:", res.data);
            };
    
            reader.readAsDataURL(blob);
        } catch (err) {
            console.error("Failed to save .docx to json-server:", err);
            alert("Failed to upload the .docx file.");
        }
    };
    
    const saveAsDocx = () => {
        const doc = new Document({
            sections: [
                {
                    properties: {},
                    children: [
                        new Paragraph({
                            children: [
                                new TextRun({
                                    text: savedContent.replace(/<[^>]+>/g, ''), // strip HTML tags
                                    font: "Arial",
                                    size: 24,
                                }),
                            ],
                        }),
                    ],
                },
            ],
        });

        Packer.toBlob(doc).then((blob) => {
            saveAs(blob, `${selectedFile?.fileName || "template"}.docx`);
        });
    };

    const handleDelete = async () => {
        if (!selectedFile?.id) {
            alert("No template selected for deletion.");
            return;
        }

        const confirmDelete = window.confirm(`Are you sure you want to delete "${selectedFile.fileName}"?`);
        if (!confirmDelete) return;

        try {
            await axios.delete(`http://localhost:8080/templates/${selectedFile.id}`);
            alert("Template deleted successfully!");
            handleClearSavedArea();
            onTemplateDeleted(); // refresh templates list
        } catch (error) {
            console.error("Error deleting template:", error);
            alert("Failed to delete the template.");
        }
    };

    return (
        <div className="saved-area">
            <div className="saved-header">
                <h3 style={{marginTop:"30px"}}>{selectedFile?.fileName || "Templates"}</h3>
                <div className="icons">
                    <FaTrash className="icon-delete" onClick={handleDelete} title="Delete Template" />
                </div>
            </div>

            {/* This renders the saved HTML properly */}
            <div
                className="template-preview"
                style={{
                    width: "1250px",
                    height: "400px",
                    overflowY: "scroll",
                    border: "1px solid #ccc",
                    padding: "10px",
                    backgroundColor: "#fff"
                }}
                dangerouslySetInnerHTML={{ __html: savedContent }}
            />

            <div className="saved-area-buttons" style={{display:"flex",width:"94%", justifyContent:"space-between",alignItems:"center"}}>
                <div style={{paddingRight:"60px"}}>
                <button className="file-button" style={{ width: 220 }}>
                    <input type="file" />
                </button>
              
                {/* <button onClick={saveAsDocx} className="buttons" style={{ marginLeft: 524 }}>Download</button> */}

                <button onClick={saveDocxToJsonServer} className="buttons" style={{ width: 220 }}>Generate</button>
                </div>
                <button onClick={saveAsDocx} className="buttons" >Download</button>

            </div>
        </div>
    );
};

export default TemplateEdit;


