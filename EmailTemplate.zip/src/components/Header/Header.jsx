import React,{useEffect,useState} from 'react';
import './Header.css';
import HTCLOGO from "./htc-logo.png";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {faCircleUser} from '@fortawesome/free-solid-svg-icons'  

const Header = () => {
    const [username, setUsername] = useState("");

    useEffect(() => {
        // Retrieve the username from localStorage
        const storedUsername = localStorage.getItem("username");
        if (storedUsername) {
            setUsername(storedUsername);
        }
    }, []);

    const handleLogout = () => {
        localStorage.removeItem("authToken"); 
        localStorage.removeItem("username");// Clear the token
        window.location.href = "/"; // Redirect to login
    }; 

    return (
        <section>
        <div class="navbar-division">
            <nav >
                <div class="navbar-space">
                    <div className="navbar-header">
                        <div>
                            <img src={HTCLOGO} className="htc-logo" alt="" />
                            
                        </div>
                        <div><h3>HR Management System</h3></div>
                        <div className="header-rightside"> 
                        <span className="username-display">   <span><FontAwesomeIcon icon={faCircleUser} className="user-icon" />{username}</span> </span><button className="logout-buttton" onClick={handleLogout}>Logout</button></div>
                    
                    </div>

                  
                </div>
            </nav>
        </div>
    </section>
    );
};

export default Header;
