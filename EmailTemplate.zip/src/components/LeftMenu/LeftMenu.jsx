// import React from 'react';
// import './LeftMenu.css';

// const LeftMenu = ({ onTemplateEditorClick, onTemplatesClick }) => {
//     return (
//         <div className="left-menu">
//             <button className="template-editor-trigger" onClick={onTemplateEditorClick}>Template Editor</button>
//             <button className="template-editor-trigger" onClick={onTemplatesClick}>View Templates</button>
//         </div>
//     );
// };

// export default LeftMenu;

import React from 'react';
import './LeftMenu.css';

const LeftMenu = ({ onTemplateEditorClick, onTemplatesClick }) => {
    return (
        <div className="left-menu">
            <button className="template-editor-trigger" onClick={onTemplateEditorClick}>
                Template Editor
            </button>
            <button className="template-editor-trigger" onClick={onTemplatesClick}>
                View Templates
            </button>
        </div>
    );
};

export default LeftMenu;

