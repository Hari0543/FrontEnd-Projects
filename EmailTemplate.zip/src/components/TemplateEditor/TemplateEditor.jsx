import React, { useState, useEffect, useRef } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import './TemplateEditor.css';
import axios from 'axios';

const TemplateEditor = ({ onSave, selectedFile }) => {
  const [template, setTemplate] = useState(selectedFile?.content || '');
  const [templatesList, setTemplatesList] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState(selectedFile || null);
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => {
    fetchTemplates();
  }, []);

  useEffect(() => {
    if (selectedFile) {
      setTemplate(selectedFile.content);
      setSelectedTemplate(selectedFile);
      setQuery(selectedFile.fileName);
    }
  }, [selectedFile]);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (inputRef.current && !inputRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  const fetchTemplates = async () => {
    try {
      const response = await axios.get("http://localhost:8080/templates");
      setTemplatesList(response.data || []);
    } catch (error) {
      console.error("Error fetching templates:", error);
    }
  };



  const clearTemplate = () => {
    setTemplate('');
    setSelectedTemplate(null);
    setQuery('');
  };

  const handleSaveClick = () => {
    const content = template;
    if (!content.trim()) {
      alert("Please enter some content before saving.");
      return;
    }

    let fileName = selectedTemplate?.fileName || prompt("Enter a template name:");
    if (!fileName) return alert("Template name is required.");

    onSave(fileName, content);
    clearTemplate();
  };

  const handleTemplateSelect = (file) => {
    setSelectedTemplate(file);
    setTemplate(file.content);
    setQuery(file.fileName);
    setIsOpen(false);
  };

  const filteredTemplates = templatesList.filter((file) =>
    file.fileName.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="template-editor">
      <div className="dropdown">
        <div className="control">
          <div className="selected-value">
            <input
              ref={inputRef}
              type="text"
              value={query}
              placeholder="Search templates..."
              onChange={(e) => {
                setQuery(e.target.value);
                setIsOpen(true);
              }}
              onClick={() => setIsOpen(true)}
              className="template-search-input"
            />
          </div>
        </div>

        {isOpen && (
          <div className="template-dropdown">
            {filteredTemplates.length > 0 ? (
              filteredTemplates.map((file, index) => (
                <div
                  key={index}
                  className="template-dropdown-item"
                  onClick={() => handleTemplateSelect(file)}
                >
                  {file.fileName}
                </div>
              ))
            ) : (
              <div className="template-dropdown-item empty">No matching templates</div>
            )}
          </div>
        )}
      </div>

      <ReactQuill
        value={template}
        onChange={setTemplate}
        theme="snow"
       
        className="text-editor"
      />

      <div>
        <button onClick={handleSaveClick}>Save</button>
        <button onClick={clearTemplate} style={{ marginLeft: '10px' }}>Clear</button>
      </div>
    </div>
  );
};

export default TemplateEditor;

