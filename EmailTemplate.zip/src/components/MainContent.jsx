// import React from 'react';
// import "./MainContent.css";

// const MainContent = ({ onViewTemplate, templates }) => {

//     const handleTemplateSelect = (e) => {
//         const selectedFileName = e.target.value;
//         if (selectedFileName) {
//             onViewTemplate(selectedFileName);
//         }
//     };

//     return (
//         <div className="main-content">
//             <h2 className="title">Templates</h2>

//             <div className="dropdown-content open">
//                 {templates.length > 0 ? (
//                     <select
//                         className="template-dropdown"
//                         onChange={handleTemplateSelect}
//                         defaultValue=""
//                         style={{ marginTop: "20px", padding: "8px", width: "300px" }}
//                     >
//                         <option value="" disabled>Select a template...</option>
//                         {templates.map((template) => (
//                             <option key={template.id} value={template.fileName}>
//                                 {template.fileName}
//                             </option>
//                         ))}
//                     </select>
//                 ) : (
//                     <p className="no-templates">🚫 No templates found.</p>
//                 )}
//             </div>
//         </div>
//     );
// };

// export default MainContent;


import React from 'react';
import "./MainContent.css";

const MainContent = ({ onViewTemplate, templates }) => {
  const handleTemplateSelect = (e) => {
    const selectedFileName = e.target.value;
    if (selectedFileName) {
      onViewTemplate(selectedFileName);
    }
  };

  return (
    <>
      <div className="main-content">
      <h2 className="title">Templates</h2>
      
    </div>
    <div style={{width:"100%", display:"flex", justifyContent:"center", alignItems:"center"}}>
    {templates.length > 0 ? (
      <select
        className="template-dropdown"
        onChange={handleTemplateSelect}
        defaultValue=""
        style={{ marginTop: "40px", paddingLeft: "20px", width: "300px"}}
      >
        <option value="" disabled>Select a template...</option>
        {templates.map((template) => (
          <option key={template.id} value={template.fileName}>
            {template.fileName}
          </option>
        ))}
      </select>
    ) : (
      <p className="no-templates">🚫 No templates found.</p>
    )}
    </div>
    </>
  );
};

export default MainContent;
