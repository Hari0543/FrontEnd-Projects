// function formatText(command) {
//     document.execCommand(command, false, null);
// }

function formatText(command) {
    document.getElementById("text-editor").focus(); // Ensure the editor is focused
    document.execCommand(command, false, null); // Still works but not recommended for future use
}

