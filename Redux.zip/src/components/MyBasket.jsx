import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchCartItems, removeFromCartServer } from "../Redux/reducer/cartSlice";

const MyBasket = () => {
  const dispatch = useDispatch();
  const cartItems = useSelector((state) => state.cart.cartItems);

  useEffect(() => {
    dispatch(fetchCartItems());
  }, [dispatch]);

  const handleRemoveFromCart = (cartItemId) => {
    dispatch(removeFromCartServer(cartItemId));
  };

  return (
    <div>
      <h1>My Basket</h1>
      {cartItems.length === 0 ? (
        <p>Your basket is empty</p>
      ) : (
        <div>
          {cartItems.map((item) => (
            <div key={item.id} style={{ borderBottom: "1px solid #ccc", marginBottom: "10px" }}>
              <h3>{item.title}</h3>
              <p>{item.price} USD</p>
              <p>Quantity: {item.quantity}</p>
              <button onClick={() => handleRemoveFromCart(item.id)}>Remove</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MyBasket;
