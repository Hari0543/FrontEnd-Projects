import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Header from "../components/Header";
import {
  fetchProducts,
  fetchCartItems,
  addToCartServer,
  removeFromCartServer,
} from "../Redux/reducer/cartSlice";

const CartPage = () => {
  const dispatch = useDispatch();
  const { products, cartItems, loading, error } = useSelector((state) => state.cart);

  useEffect(() => {
    dispatch(fetchProducts());
    dispatch(fetchCartItems());
  }, [dispatch]);

  const handleAddToCart = (product) => {
    dispatch(addToCartServer(product));
  };

  const handleRemoveFromCart = (cartItemId) => {
    dispatch(removeFromCartServer(cartItemId));
  };

  return (
    <div>
      <Header />
      <div>
        <h1>Cart Page</h1>
        {loading && <p>Loading...</p>}
        {error && <p style={{ color: "red" }}>Error: {error}</p>}

        <h2>Products</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "10px" }}>
          {products.map((product) => (
            <div key={product.id} style={{ border: "1px solid #ccc", padding: "10px" }}>
              <h3>{product.title}</h3>
              <p>{product.price} USD</p>
              <button onClick={() => handleAddToCart(product)}>Add to Cart</button>
            </div>
          ))}
        </div>

        <h2>Cart Items</h2>
        {cartItems.length === 0 ? (
          <p>Your cart is empty</p>
        ) : (
          <div>
            {cartItems.map((item) => (
              <div key={item.id} style={{ borderBottom: "1px solid #ccc", marginBottom: "10px" }}>
                <h3>{item.title}</h3>
                <p>{item.price} USD</p>
                <p>Quantity: {item.quantity}</p>
                <button onClick={() => handleRemoveFromCart(item.id)}>Remove</button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CartPage;
