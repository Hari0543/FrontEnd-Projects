import React from "react";
import { AiOutlineShoppingCart } from "react-icons/ai"; 
import { Link } from "react-router-dom"; 

const Header = () => {
  return (
    <header style={styles.header}>
      <h1 style={styles.title}>My Store</h1>
      <Link to="/my-basket" style={styles.link}> 
        <AiOutlineShoppingCart style={styles.cartIcon} />
      </Link>
    </header>
  );
};


const styles = {
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "10px 20px",
    backgroundColor: "#f8f9fa",
    boxShadow: "0 2px 5px rgba(0, 0, 0, 0.1)",
  },
  title: {
    fontSize: "24px",
    fontWeight: "bold",
    color: "#333",
  },
  cartIcon: {
    fontSize: "28px",
    color: "#333",
    cursor: "pointer",
  },
  link: {
    textDecoration: "none", 
    color: "inherit",       
  },
};

export default Header;
