import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

// Replace with your actual server URL
const API_URL = "https://fakestoreapi.com/products";
const CART_API = "http://localhost:5000/cartItems";

// Thunk to fetch product list
export const fetchProducts = createAsyncThunk(
  "cart/fetchProducts",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(API_URL);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

// Thunk to fetch cart from server
export const fetchCartItems = createAsyncThunk(
  "cart/fetchCartItems",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(CART_API);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

// Thunk to add item to cart
export const addToCartServer = createAsyncThunk(
  "cart/addToCartServer",
  async (product, { rejectWithValue }) => {
    try {
      const response = await axios.post(CART_API, {
        productId: product.id, 
        title: product.title,
        price: product.price,
        quantity: 1,
      });
      return response.data;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

// Thunk to remove item from cart
export const removeFromCartServer = createAsyncThunk(
  "cart/removeFromCartServer",
  async (cartItemId, { rejectWithValue }) => {
    try {
      await axios.delete(`${CART_API}/${cartItemId}`);
      return cartItemId;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

const cartSlice = createSlice({
  name: "cart",
  initialState: {
    products: [],
    cartItems: [],
    loading: false,
    error: null,
  },
  extraReducers: (builder) => {
    builder
      // Products
      .addCase(fetchProducts.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchProducts.fulfilled, (state, action) => {
        state.products = action.payload;
        state.loading = false;
      })
      .addCase(fetchProducts.rejected, (state, action) => {
        state.error = action.payload;
        state.loading = false;
      })
      // Cart Items
      .addCase(fetchCartItems.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchCartItems.fulfilled, (state, action) => {
        state.cartItems = action.payload;
        state.loading = false;
      })
      .addCase(fetchCartItems.rejected, (state, action) => {
        state.error = action.payload;
        state.loading = false;
      })
      // Add to Cart
      .addCase(addToCartServer.fulfilled, (state, action) => {
        state.cartItems.push(action.payload);
      })
      // Remove from Cart
      .addCase(removeFromCartServer.fulfilled, (state, action) => {
        state.cartItems = state.cartItems.filter(
          (item) => item.id !== action.payload
        );
      });
  },
});

export const { clearCart } = cartSlice.actions;

export default cartSlice.reducer;
