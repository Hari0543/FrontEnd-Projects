import React from "react";
import { Provider } from "react-redux";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"; // Import React Router components
import store from "../src/Redux/store";
import CartPage from "../src/components/CartPage";
import MyBasket from "../src/components/MyBasket"; // Import MyBasket page

const App = () => {
  return (
    <Provider store={store}>
      <Router>
        <Routes>         
          <Route path="/" element={<CartPage />} />
          <Route path="/my-basket" element={<MyBasket />} />
        </Routes>
      </Router>
    </Provider>
  );
};

export default App;
