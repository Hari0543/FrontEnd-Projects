import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';

const firebaseConfig = {
  apiKey: "AIzaSyCFeB-8Q8Ct3lPxYvsOdK0KcNizkukt4rs",
  authDomain: "doctor-appointment-b7816.firebaseapp.com",
  projectId: "doctor-appointment-b7816",
  storageBucket: "doctor-appointment-b7816.appspot.com",
  messagingSenderId: "988017789706",
  appId: "1:988017789706:web:20349a1437ec6e8c9108f3",
  measurementId: "G-NCFY5HX90S",
};

// Initialize Firebase
const firebaseApp = firebase.initializeApp(firebaseConfig);
const auth = firebaseApp.auth();

export { auth };
