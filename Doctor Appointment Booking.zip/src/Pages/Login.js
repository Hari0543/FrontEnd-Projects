import React, { useState } from 'react';
import "./login.css";
import { useNavigate } from "react-router-dom";
import { auth } from '../firebase'; 

function Login() {
  const navigate = useNavigate();
  const [credentials, setCredentials] = useState({
    username: '',
    password: '',
  });

  const [notification, setNotification] = useState(null);

  const handleInputChange = (event) => {
    const { name, value } = event.target;

    setCredentials((prevCredentials) => ({
      ...prevCredentials,
      [name]: value, 
    }));

    const inputElement = document.getElementById(name);
    if (inputElement) {
      if (name === "password") inputElement.type = "password";
      inputElement.style.fontFamily = "Montserrat black";
    }
  };

  const setEmptyValue = (event) => {
    const { name } = event.target;
    const inputElement = document.getElementById(name);
    if (inputElement) inputElement.value = "";
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const { username, password } = credentials;
  
    if (!username) {
      setNotification("Enter your email.");
    } else if (!password) {
      setNotification("Enter your password.");
    } else {
      try {
        // Firebase Authentication Logic
        await auth.signInWithEmailAndPassword(username, password);
        setNotification("Login Successful!");
        navigate("/home"); 
      } catch (error) {
        setNotification(error.message); 
      }
    }
  
    setTimeout(() => setNotification(null), 3000); 
  };
  

  const handleNavigateToSignup = () => {
    navigate("/signup");
  };

  return (
    <div className="login">
      <h4>Login</h4>

  
      {notification && <div className="notification">{notification}</div>}

      <form onSubmit={handleSubmit}>
        <div className="text_area">
          <input
            type="email"
            id="username"
            name="username"
            placeholder="Enter your email"
            onChange={handleInputChange}
            onFocus={setEmptyValue}
            className="text_input"
          />
        </div>
        <div className="text_area">
          <input
            type="password"
            id="password"
            name="password"
            placeholder="Enter your password"
            onChange={handleInputChange}
            onFocus={setEmptyValue}
            className="text_input"
          />
        </div>
        <input
          type="submit"
          value="Login"
          className="btn"
        />
      </form>

      <button
        className="navbar-btn"
        type="button"
        onClick={handleNavigateToSignup}
      >
        Signup
      </button>
    </div>
  );
}

export default Login;
