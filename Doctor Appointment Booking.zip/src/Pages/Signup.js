import React, { useState } from 'react'; 
import "./login.css";
import { useNavigate } from "react-router-dom";
import { auth } from '../firebase'; 

function Signup() {
  const navigate = useNavigate();
  const [credentials, setCredentials] = useState({
    email: '',
    password: '',
  });

  const [notification, setNotification] = useState(null); 
  const handleInputChange = (event) => {
    const { name, value } = event.target;

    setCredentials((prevCredentials) => ({
      ...prevCredentials,
      [name]: value, 
    }));
  };

  const setEmptyValue = (event) => {
    const { name } = event.target;
    const inputElement = document.getElementById(name);
    if (inputElement) inputElement.value = "";
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const { email, password } = credentials;

    if (!email) {
      setNotification("Enter your email.");
    } else if (!password) {
      setNotification("Enter your password.");
    } else {
      try {
        
        await auth.createUserWithEmailAndPassword(email, password);
        setNotification("Signup successful!");
        setTimeout(() => navigate("/login"), 3000);
      } catch (error) {
        setNotification(error.message); 
      }
    }

    setTimeout(() => setNotification(null), 3000); 
  };

  const handleNavigateToLogin = () => {
    navigate("/login");
  };

  return (
    <div className="login">
      <h4>Signup</h4>

      {/* Notification Pop-up */}
      {notification && <div className="notification">{notification}</div>}

      <form onSubmit={handleSubmit}>
        <div className="text_area">
          <input
            type="email"
            id="email"
            name="email"
            placeholder="Enter your email"
            onChange={handleInputChange}
            onFocus={setEmptyValue}
            className="text_input"
          />
        </div>
        <div className="text_area">
          <input
            type="password"
            id="password"
            name="password"
            placeholder="Enter your password"
            onChange={handleInputChange}
            onFocus={setEmptyValue}
            className="text_input"
          />
        </div>
        <input
          type="submit"
          value="Signup"
          className="btn"
        />
      </form>
    
      <button
        className="navbar-btn"
        type="button"
        onClick={handleNavigateToLogin}
      >
        Login
      </button>
    </div>
  );
}

export default Signup;
