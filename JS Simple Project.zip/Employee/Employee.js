$(document).ready(function() {
 
    $('#loginForm').submit(function(event) {
        event.preventDefault();

        let username = $('#username').val().trim();
        let password = $('#password').val().trim();

        if (username === '' || password === '') {
            alert('Both username and password are required.');
        } else {
            $('.login-container').hide();
            $('.expense-container').show();
            fetchExpenses(); 
        }
    });
})


$('#expenseForm').submit(function(event) {
    event.preventDefault();

    let category = $('#category').val().trim();
    let amount = $('#amount').val().trim();
    let date = $('#date').val().trim();
    let purpose = $('#purpose').val().trim();
    let currency = $('#currency').val();

    if (category ==='' || date ==='' || purpose ==='' || amount === '' || currency === '') {
        alert('All fields are required.');
    } else {
        
        let expenseData = {
            category: category,
            amount: amount,
            date: date,
            purpose: purpose,
            currency: currency,
            status: 'Pending' 
        };

       
        fetch('http://localhost:3005/expenses', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(expenseData)
        })
        .then(response => {
            if (response.ok) {
                return response.json();
            } else {
                throw new Error('Failed to save data.');
            }
        })
        .then(data => {
            console.log('Expense submitted:', data);
            alert('Expense submitted successfully!');
            
            $('#expenseForm')[0].reset();
            fetchExpenses();
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while submitting the expense.');
        });
    }
});


function fetchExpenses() {
    fetch('http://localhost:3005/expenses')
    .then(response => response.json())
    .then(data => {
        const tableBody = document.getElementById('expenseTable').getElementsByTagName('tbody')[0];
        tableBody.innerHTML = ''; 
        data.forEach(item => {
            const row = document.createElement('tr');

            const categoryCell = document.createElement('td');
            categoryCell.textContent = item.category;
            row.appendChild(categoryCell);

            const amountCell = document.createElement('td');
            amountCell.textContent = item.amount;
            row.appendChild(amountCell);

            const dateCell = document.createElement('td');
            dateCell.textContent = item.date;
            row.appendChild(dateCell);

            const currencyCell = document.createElement('td');
            currencyCell.textContent = item.currency;
            row.appendChild(currencyCell);

            const purposeCell = document.createElement('td');
            purposeCell.textContent = item.purpose;
            row.appendChild(purposeCell);

            const statusCell = document.createElement('td');
            statusCell.textContent = item.status;
            row.appendChild(statusCell);

            tableBody.appendChild(row);
        });
    })
    .catch(error => console.error('Error fetching data:', error));
}


if ($('.expense-container').is(':visible')) {
    fetchExpenses();
}




