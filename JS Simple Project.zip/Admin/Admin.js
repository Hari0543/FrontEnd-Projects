document.addEventListener('DOMContentLoaded', () => {
    const userForm = document.getElementById('user-form');
    const userNameInput = document.getElementById('user-name');
    const userRoleInput = document.getElementById('user-role');
    const userTableBody = document.getElementById('user-table-body');

  
    const fetchUsers = async () => {
        const response = await fetch('http://localhost:4002/users');
        const users = await response.json();
        userTableBody.innerHTML = '';

        users.forEach(user => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${user.id}</td>
                <td>${user.name}</td>
                <td>${user.role}</td>
                <td>
                    <button class="edit-button" data-id="${user.id}">Edit</button>
                    <button class="delete-button" data-id="${user.id}">Delete</button>
                </td>
            `;
            userTableBody.appendChild(row);
        });
    };

    userForm.addEventListener('submit', async (e) => {

        const newUser = {
            name: userNameInput.value,
            role: userRoleInput.value
        };

        await fetch('http://localhost:4002/users', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newUser)
        });

        userNameInput.value = '';
        userRoleInput.value = '';
        fetchUsers(); 
    });

    userTableBody.addEventListener('click', async (e) => {
        
        const target = e.target;

        
        if (target.classList.contains('edit-button')) {
            const id = target.getAttribute('data-id');
            const name = prompt('Enter new name:');
            const role = prompt('Enter new role:');
            if (name && role) {
                await fetch(`http://localhost:4002/users/${id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name, role })
                });
                fetchUsers(); 
            }
        }

   
        if (target.classList.contains('delete-button')) {
            const id = target.getAttribute('data-id');
            const confirmDelete = confirm('Are you sure you want to delete this user?');
            if (confirmDelete) {
                await fetch(`http://localhost:4002/users/${id}`, {
                    method: 'DELETE'
                });
                fetchUsers(); 
            }
        }
    });

    fetchUsers();
});
