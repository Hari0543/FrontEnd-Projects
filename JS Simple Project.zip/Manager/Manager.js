$(document).ready(function() {
    let isLoggedIn = false;


    $('#loginForm').submit(function(event) {
        event.preventDefault();

        let username = $('#username').val().trim();
        let password = $('#password').val().trim();

        if (username === '' || password === '') {
            alert('Both username and password are required.');
        } else {
            isLoggedIn = true;
            $('.login-container').hide();
            $('.expense-container').show();
            fetchExpenses(); 
        }
    });

   
    function fetchExpenses() {
        fetch('http://localhost:3006/expenses')
            .then(response => response.json())
            .then(data => {
                const tableBody = document.getElementById('managerExpenseTable').getElementsByTagName('tbody')[0];
                tableBody.innerHTML = ''; 

                data.forEach(item => {
                    const row = document.createElement('tr');

                    const categoryCell = document.createElement('td');
                    categoryCell.textContent = item.category;
                    row.appendChild(categoryCell);

                    const amountCell = document.createElement('td');
                    amountCell.textContent = item.amount;
                    row.appendChild(amountCell);

                    const dateCell = document.createElement('td');
                    dateCell.textContent = item.date;
                    row.appendChild(dateCell);

                    const currencyCell = document.createElement('td');
                    currencyCell.textContent = item.currency;
                    row.appendChild(currencyCell);

                    const purposeCell = document.createElement('td');
                    purposeCell.textContent = item.purpose;
                    row.appendChild(purposeCell);

                    const statusCell = document.createElement('td');
                    statusCell.textContent = item.status;
                    row.appendChild(statusCell);

                    const commentCell = document.createElement('td');
                    const commentInput = document.createElement('input');
                    commentInput.type = 'text';
                    commentInput.value = item.comment || '';
                    commentCell.appendChild(commentInput);
                    row.appendChild(commentCell);

                    const actionCell = document.createElement('td');
                    const approveButton = document.createElement('button');
                    approveButton.textContent = 'Approve';
                    approveButton.addEventListener('click', () => updateExpenseStatus(item.id, 'Approved', commentInput.value));

                    const rejectButton = document.createElement('button');
                    rejectButton.textContent = 'Reject';
                    rejectButton.addEventListener('click', () => updateExpenseStatus(item.id, 'Rejected', commentInput.value));

                    actionCell.appendChild(approveButton);
                    actionCell.appendChild(rejectButton);
                    row.appendChild(actionCell);

                    tableBody.appendChild(row);
                });
            })
            .catch(error => console.error('Error fetching data:', error));
    }

    // Update expense status
    function updateExpenseStatus(id, status, comment) {
        fetch(`http://localhost:3005/expenses/${id}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ status: status, comment: comment })
        })
        .then(response => {
            if (response.ok) {
                fetchExpenses(); 
            } else {
                throw new Error('Failed to update status.');
            }
        })
        .catch(error => console.error('Error updating status:', error));
    }
});
